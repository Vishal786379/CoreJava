package calculations;
public class ScientificCalculator extends SimpleCalcualator{
    float pi = 3.14f;

    double areaOfCircle(double r){
        return pi*r*r;
    }
}
