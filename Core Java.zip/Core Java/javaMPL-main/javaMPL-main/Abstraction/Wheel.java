package Abstraction;

// Makes the statement as A (Circle) is capable of doing as B (Wheel)
public interface Wheel {
    public void roll(int rotations);
}
