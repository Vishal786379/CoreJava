package AccessModifiers.TestPackage;

public class b {
    void defaultMethod(){
        System.out.println("This is default Method: b");
    }

    public void publicMethod(){
        System.out.println("This is public Method: b");
    }

    private void privateMethod(){
        System.out.println("This is private Method: b");
    }

    protected void protectedMethod(){
        System.out.println("This is protected Method: b");
    }
}
