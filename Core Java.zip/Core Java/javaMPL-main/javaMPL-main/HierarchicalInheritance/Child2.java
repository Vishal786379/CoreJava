package HierarchicalInheritance;

public class Child2 extends Parent1{
    void child2Method1(){
        System.out.println("This is child2 Method1");
    }
}
