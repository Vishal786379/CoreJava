package HierarchicalInheritance;

public class Parent1 {
    void parent1Method1(){
        System.out.println("This is parent1Method1");
    }
}
