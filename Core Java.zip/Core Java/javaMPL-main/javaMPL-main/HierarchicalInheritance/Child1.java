package HierarchicalInheritance;

public class Child1 extends Parent1{
    void child1Method1(){
        System.out.println("This is child1 Method1");
    }
}
