package MultiLevelInheritance;

public class Grandparent {
    void grandParentClassMethod(){
        System.out.println("This is grandParentClassMethod");
    }
}
