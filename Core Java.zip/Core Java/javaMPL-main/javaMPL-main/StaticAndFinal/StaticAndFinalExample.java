package StaticAndFinal;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;

public class StaticAndFinalExample {
    public static void main(String[] args) {

        Student s1 = new Student("Sagar");
        System.out.println(s1.eat());

        /* Scanner sc = new Scanner(System.in);
        String name; */
        // Using className.StaticMemberName syntax to access static members 
        /* Student.setClgName("IIT Mumbai");

        ArrayList<Student> divisiona = new ArrayList<>();

        System.out.println("Enter a number: ");
        int n = sc.nextInt();

        sc.nextLine();

        Student st = null;

        for(int i=1;i<=n;i++){
            System.out.println("Enter Name: ");
            name = sc.next();
            st = new Student(name);
            divisiona.add(st);
        }
        
        for(int i=0;i<n;i++){
            System.out.println(divisiona.get(i).toString());
        } */
        
    }
}
